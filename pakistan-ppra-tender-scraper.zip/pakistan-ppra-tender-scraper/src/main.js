/**
 * Pakistan PPRA Tender Scraper — Apify Actor entry point.
 *
 * Each source runs in its own isolated crawler with its own request queue, so
 * a portal that is down, has moved, or has been redesigned fails alone: the
 * error is logged, recorded in the run summary, and the remaining sources
 * continue. Normalization, filtering and de-duplication happen after
 * collection, which is what keeps every portal's output on one contract.
 *
 * Scope: publicly accessible procurement information only. No authentication,
 * no CAPTCHA solving, no access-controlled or non-public area is touched.
 */

import { Actor, log } from 'apify';
import { CheerioCrawler, PlaywrightCrawler } from 'crawlee';

import { resolveAdapters, ALL_SOURCE_KEYS } from './adapters/index.js';
import { finalizeWithoutDetail, mergeRawItem } from './adapters/base.js';
import { Deduplicator } from './lib/deduplicate.js';
import { nowIso } from './lib/dates.js';
import { applyDocumentFlags } from './lib/documents.js';
import { evaluateTender, pageIsOlderThanWindow, sortTenders } from './lib/filters.js';
import { comparisonKey, normalizeTender } from './lib/normalize.js';

/* ------------------------------------------------------------------ */
/* Input                                                               */
/* ------------------------------------------------------------------ */

const DEFAULTS = {
    sources: ALL_SOURCE_KEYS,
    keyword: null,
    reference: null,
    description: null,
    departments: [],
    procuringAgencies: [],
    provinces: [],
    cities: [],
    procurementCategories: [],
    sectors: [],
    noticeTypes: [],
    publishedFrom: null,
    publishedTo: null,
    deadlineFrom: null,
    deadlineTo: null,
    activeOnly: true,
    includeDetails: true,
    includeDocuments: true,
    includeCorrigenda: true,
    includeEvaluationReports: true,
    includeAwards: false,
    maxItems: 100,
    maxItemsPerSource: 0,
    sortField: 'closingDate',
    sortAscending: true,
};

function resolveInput(raw = {}) {
    const input = { ...DEFAULTS, ...raw };

    for (const key of ['departments', 'procuringAgencies', 'provinces', 'cities', 'procurementCategories', 'sectors', 'noticeTypes', 'sources']) {
        if (!Array.isArray(input[key])) input[key] = input[key] ? [input[key]] : [];
    }
    if (!input.sources.length) input.sources = ALL_SOURCE_KEYS;

    input.maxItems = Number.isFinite(Number(input.maxItems)) ? Math.max(0, Number(input.maxItems)) : DEFAULTS.maxItems;
    input.maxItemsPerSource = Number.isFinite(Number(input.maxItemsPerSource)) ? Math.max(0, Number(input.maxItemsPerSource)) : 0;

    return input;
}

/* ------------------------------------------------------------------ */
/* Collection state                                                    */
/* ------------------------------------------------------------------ */

/** Stable per-source key for a raw list item, used to merge in detail data. */
function itemKey(adapter, item) {
    const id = item.tenderId ?? item.referenceNumber;
    if (id) return `${adapter.key}|id|${comparisonKey(id)}`;
    if (item.detailUrl) return `${adapter.key}|url|${item.detailUrl}`;
    return `${adapter.key}|fb|${comparisonKey(item.title)}|${comparisonKey(item.procuringAgency)}|${item.closingDate ?? ''}`;
}

/** Per-source collector: raw items keyed by {@link itemKey}. */
class SourceCollector {
    constructor(adapter, limit) {
        this.adapter = adapter;
        this.limit = limit || Infinity;
        this.items = new Map();
        this.listPages = 0;
        this.detailPages = 0;
        this.errors = [];
    }

    get full() {
        return this.items.size >= this.limit;
    }

    /** Adds a list item; returns its key, or null when it was a duplicate/over limit. */
    addListItem(item) {
        const key = itemKey(this.adapter, item);
        if (this.items.has(key)) {
            // Merge any newly discovered fields into the existing entry.
            const existing = this.items.get(key);
            for (const [field, value] of Object.entries(item)) {
                if (existing[field] == null && value != null) existing[field] = value;
            }
            return null;
        }
        if (this.full) return null;
        this.items.set(key, item);
        return key;
    }

    applyDetail(key, patch) {
        const existing = this.items.get(key);
        if (!existing) return;
        const merged = mergeRawItem(existing, patch);
        merged._detailVisited = true;
        this.items.set(key, merged);
    }
}

/* ------------------------------------------------------------------ */
/* Crawler construction                                                */
/* ------------------------------------------------------------------ */

const NON_RETRYABLE = /\b(400|401|403|404|405|410|451)\b/;

function baseCrawlerOptions(adapter, collector, requestQueue) {
    return {
        requestQueue,
        maxRequestRetries: 3,
        navigationTimeoutSecs: 60,
        requestHandlerTimeoutSecs: 120,
        maxRequestsPerCrawl: 2000,
        maxConcurrency: 4,

        /**
         * Permanent client errors (above all 404) must not burn retries: mark
         * them no-retry on the first failure. Server errors keep their retries.
         */
        errorHandler: async ({ request, log: contextLog }, error) => {
            if (NON_RETRYABLE.test(error?.message ?? '')) {
                request.noRetry = true;
                contextLog.debug(`[${adapter.key}] Permanent error, not retrying: ${request.url}`);
            }
        },

        /** A failed request is recorded and never propagated to the run. */
        failedRequestHandler: async ({ request }, error) => {
            const message = `${request.userData?.label ?? 'REQUEST'} ${request.url} — ${error?.message ?? 'unknown error'}`;
            collector.errors.push(message);
            log.warning(`[${adapter.key}] ${message}`);
        },

        ...adapter.crawlerOptions,
    };
}

/**
 * Handles one listing document (already parsed into Cheerio) for both engines.
 * Returns the list of follow-up listing URLs the adapter wants to visit.
 */
async function handleListDocument(ctx, collector, input, enqueueDetail) {
    const { adapter, request } = ctx;

    let parsed;
    try {
        parsed = adapter.parseList(ctx) ?? { items: [] };
    } catch (error) {
        collector.errors.push(`parseList failed for ${request.url} — ${error.message}`);
        log.warning(`[${adapter.key}] parseList failed for ${request.url}: ${error.message}`);
        return { items: [], nextUrls: [] };
    }

    const items = parsed.items ?? [];
    collector.listPages += 1;

    if (!items.length) {
        log.debug(`[${adapter.key}] No rows collected on ${request.url}`);
        // An adapter may deliberately yield no rows yet still ask for a follow-up
        // page (GB uses page 1 only to discover the last page). Generic adapters
        // return no follow-ups on an empty page, so this cannot loop.
        return { items, nextUrls: parsed.nextUrls ?? [] };
    }

    const added = [];
    for (const item of items) {
        if (collector.full) break;
        const key = collector.addListItem(item);
        if (key) added.push({ key, item });
    }

    if (input.includeDetails && enqueueDetail) {
        for (const { key, item } of added) {
            if (item.detailUrl) await enqueueDetail(item.detailUrl, key);
        }
    }

    // Early stop: the portal sorts newest-first and this page is already older
    // than the requested publication window. Only evaluated when both the
    // adapter and the input make the check meaningful.
    if (adapter.descendingByPublishedDate && input.publishedFrom) {
        const preview = items.map((item) => normalizeTender(item, adapter, { scrapedAt: nowIso() }));
        if (pageIsOlderThanWindow(preview, input, adapter)) {
            log.info(`[${adapter.key}] Reached the publishedFrom boundary — stopping pagination.`);
            return { items, nextUrls: [] };
        }
    }

    return { items, nextUrls: collector.full ? [] : (parsed.nextUrls ?? []) };
}

/** Runs a Cheerio-based source. */
async function runCheerioSource(adapter, input, collector, requestQueue) {
    const crawler = new CheerioCrawler({
        ...baseCrawlerOptions(adapter, collector, requestQueue),

        async requestHandler(context) {
            const { $, request, response } = context;

            if (response?.statusCode && response.statusCode >= 400) {
                collector.errors.push(`HTTP ${response.statusCode} for ${request.url}`);
                return;
            }

            const ctx = { ...context, adapter, input, log: context.log };

            // NOTE: the per-source cap gates LIST pages only. Detail requests
            // enrich items that are already collected and must still run once
            // the cap has been hit.
            if (request.userData?.label === 'DETAIL') {
                collector.detailPages += 1;
                try {
                    const patch = adapter.parseDetail(ctx) ?? {};
                    collector.applyDetail(request.userData.itemKey, patch);
                } catch (error) {
                    collector.errors.push(`parseDetail failed for ${request.url} — ${error.message}`);
                }
                return;
            }

            if (collector.full) return;

            const enqueueDetail = async (url, key) => {
                await requestQueue.addRequest({
                    url,
                    userData: { label: 'DETAIL', source: adapter.key, itemKey: key },
                }, { forefront: false });
            };

            const { nextUrls } = await handleListDocument({ ...ctx, $ }, collector, input, enqueueDetail);

            for (const url of nextUrls) {
                await requestQueue.addRequest({
                    url,
                    userData: { label: 'LIST', source: adapter.key },
                });
            }
        },
    });

    await crawler.run();
}

/** Runs a Playwright-based source (currently Punjab's WebForms grid). */
async function runPlaywrightSource(adapter, input, collector, requestQueue) {
    const crawler = new PlaywrightCrawler({
        ...baseCrawlerOptions(adapter, collector, requestQueue),
        headless: true,
        launchContext: {
            launchOptions: {
                args: ['--no-sandbox', '--disable-dev-shm-usage'],
                // Escape hatch for images whose bundled Chromium sits elsewhere.
                ...(process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH
                    ? { executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH }
                    : {}),
            },
        },

        async requestHandler(context) {
            const { page, request, parseWithCheerio } = context;

            // As above: the cap gates listing pages, not detail enrichment.
            if (request.userData?.label === 'DETAIL') {
                collector.detailPages += 1;
                const $ = await parseWithCheerio();
                try {
                    const patch = adapter.parseDetail({ ...context, $, adapter, input });
                    collector.applyDetail(request.userData.itemKey, patch ?? {});
                } catch (error) {
                    collector.errors.push(`parseDetail failed for ${request.url} — ${error.message}`);
                }
                return;
            }

            if (collector.full) return;

            const enqueueDetail = async (url, key) => {
                await requestQueue.addRequest({
                    url,
                    userData: { label: 'DETAIL', source: adapter.key, itemKey: key },
                });
            };

            // In-page pagination: postback grids never change their URL, so the
            // whole listing is walked inside this single request.
            let pageNumber = 1;
            const maxPages = 200;

            while (pageNumber <= maxPages) {
                const $ = await parseWithCheerio();
                const ctx = { ...context, $, adapter, input, pageNumber, log: context.log };

                const { items } = await handleListDocument(ctx, collector, input, enqueueDetail);
                if (!items.length || collector.full) break;
                if (typeof adapter.gotoNextPage !== 'function') break;

                let moved = false;
                try {
                    moved = await adapter.gotoNextPage({ page, pageNumber: pageNumber + 1, log: context.log, adapter });
                } catch (error) {
                    collector.errors.push(`pagination stopped at page ${pageNumber} — ${error.message}`);
                }
                if (!moved) break;
                pageNumber += 1;
            }
        },
    });

    await crawler.run();
}

/* ------------------------------------------------------------------ */
/* Per-source pipeline                                                 */
/* ------------------------------------------------------------------ */

async function runSource(adapter, input, state) {
    const perSourceLimit = input.maxItemsPerSource || 0;
    const collector = new SourceCollector(adapter, perSourceLimit);

    const queueName = `ppra-${adapter.key}-${Date.now().toString(36)}`;
    const requestQueue = await Actor.openRequestQueue(queueName);

    const startRequests = adapter.startRequests(input) ?? [];
    for (const request of startRequests) {
        await requestQueue.addRequest({
            userData: { label: 'LIST', source: adapter.key },
            ...request,
        });
    }

    log.info(`[${adapter.key}] Starting ${adapter.name} with ${startRequests.length} entry point(s), engine=${adapter.engine}.`);

    if (adapter.engine === 'playwright') await runPlaywrightSource(adapter, input, collector, requestQueue);
    else await runCheerioSource(adapter, input, collector, requestQueue);

    await requestQueue.drop().catch(() => {});

    return finalizeSource(adapter, collector, input, state);
}

/** Normalizes, filters and de-duplicates one source's raw items. */
function finalizeSource(adapter, collector, input, state) {
    const scrapedAt = nowIso();
    const now = new Date();

    const stats = {
        source: adapter.key,
        sourceName: adapter.name,
        listPages: collector.listPages,
        detailPages: collector.detailPages,
        collected: collector.items.size,
        saved: 0,
        filteredOut: 0,
        duplicates: 0,
        restricted: 0,
        errors: collector.errors.slice(0, 25),
        errorCount: collector.errors.length,
    };

    for (const raw of collector.items.values()) {
        if (input.maxItems && state.results.length >= input.maxItems) break;

        const prepared = raw.documents ? raw : finalizeWithoutDetail(raw);
        const record = normalizeTender(prepared, adapter, { scrapedAt, now });

        Object.assign(record, applyDocumentFlags({
            documents: record.documents,
            corrigenda: record.corrigenda,
            evaluationReports: record.evaluationReports,
            contractAwards: record.contractAwards,
        }, input));

        const verdict = evaluateTender(record, input, now);
        if (!verdict.keep) {
            stats.filteredOut += 1;
            if (verdict.reason === 'restricted_category') stats.restricted += 1;
            continue;
        }

        if (!state.deduper.add(record)) {
            stats.duplicates += 1;
            continue;
        }

        state.results.push(record);
        stats.saved += 1;
    }

    return stats;
}

/* ------------------------------------------------------------------ */
/* Entry point                                                         */
/* ------------------------------------------------------------------ */

await Actor.init();

try {
    const input = resolveInput((await Actor.getInput()) ?? {});
    const { adapters, unknown } = resolveAdapters(input.sources);

    if (unknown.length) log.warning(`Ignoring unknown source key(s): ${unknown.join(', ')}`);
    if (!adapters.length) throw new Error('No valid sources selected — nothing to crawl.');

    log.info(`Crawling ${adapters.length} source(s): ${adapters.map((a) => a.key).join(', ')}`);
    log.info(`Limits: maxItems=${input.maxItems || 'unlimited'}, maxItemsPerSource=${input.maxItemsPerSource || 'unlimited'}, includeDetails=${input.includeDetails}, activeOnly=${input.activeOnly}`);

    const state = {
        results: [],
        deduper: new Deduplicator(),
    };

    const perSource = [];

    for (const adapter of adapters) {
        if (input.maxItems && state.results.length >= input.maxItems) {
            log.info(`Global maxItems (${input.maxItems}) reached — skipping ${adapter.key}.`);
            perSource.push({ source: adapter.key, sourceName: adapter.name, skipped: 'maxItems reached', saved: 0 });
            continue;
        }

        try {
            const stats = await runSource(adapter, input, state);
            perSource.push(stats);
            log.info(`[${adapter.key}] Done — collected ${stats.collected}, saved ${stats.saved}, filtered ${stats.filteredOut}, duplicates ${stats.duplicates}, errors ${stats.errorCount}.`);
        } catch (error) {
            // A source failing must never end the run.
            log.exception(error, `[${adapter.key}] Source failed and was skipped.`);
            perSource.push({
                source: adapter.key,
                sourceName: adapter.name,
                collected: 0,
                saved: 0,
                fatalError: error?.message ?? String(error),
            });
        }
    }

    const sorted = sortTenders(state.results, input.sortField, input.sortAscending);
    const limited = input.maxItems ? sorted.slice(0, input.maxItems) : sorted;

    const CHUNK = 500;
    for (let index = 0; index < limited.length; index += CHUNK) {
        await Actor.pushData(limited.slice(index, index + CHUNK));
    }

    const summary = {
        finishedAt: nowIso(),
        requestedSources: input.sources,
        totalSaved: limited.length,
        totalDuplicatesSkipped: state.deduper.duplicates,
        sources: perSource,
        input: {
            activeOnly: input.activeOnly,
            includeDetails: input.includeDetails,
            includeDocuments: input.includeDocuments,
            includeCorrigenda: input.includeCorrigenda,
            includeEvaluationReports: input.includeEvaluationReports,
            includeAwards: input.includeAwards,
            maxItems: input.maxItems,
            maxItemsPerSource: input.maxItemsPerSource,
            sortField: input.sortField,
            sortAscending: input.sortAscending,
        },
    };

    await Actor.setValue('RUN_SUMMARY', summary);

    log.info(`Finished. Saved ${limited.length} tender(s); skipped ${state.deduper.duplicates} duplicate(s).`);
    for (const stats of perSource) {
        if (stats.fatalError) log.warning(`  ${stats.source}: FAILED — ${stats.fatalError}`);
        else if (stats.skipped) log.info(`  ${stats.source}: skipped (${stats.skipped})`);
        else log.info(`  ${stats.source}: ${stats.saved} saved of ${stats.collected} collected`);
    }
} finally {
    await Actor.exit();
}
