/**
 * Shared building blocks for source adapters.
 *
 * ADAPTER CONTRACT
 * ----------------
 * Every file in `src/adapters/` default-exports an object shaped like:
 *
 *   {
 *     key, name, province, country, baseUrl,
 *     engine: 'cheerio' | 'playwright',
 *     crawlerOptions?: object,                 // merged into the crawler config
 *     descendingByPublishedDate?: boolean,     // enables the early pagination stop
 *     startRequests(input) -> Array<{ url, userData? }>,
 *     parseList(ctx)   -> { items: RawItem[], nextUrls?: string[] },
 *     parseDetail(ctx) -> Partial<RawItem>,
 *     gotoNextPage?(ctx) -> Promise<boolean>   // playwright engine only
 *   }
 *
 * `ctx` is `{ $, request, response, input, log, adapter, pageNumber, page? }`.
 *
 * A RawItem uses the canonical field names from `lib/normalize.js`. Adapters
 * never build the final record — `normalizeTender()` does — so a portal
 * adapter can be repaired without touching the dataset contract.
 */

import {
    absoluteUrl,
    cleanBlock,
    cleanText,
    extractLabelledValues,
    extractTableRows,
} from '../lib/normalize.js';
import {
    bucketDocuments,
    extractDocuments,
    extractExternalLinks,
    looksLikeDocument,
    mergeDocuments,
} from '../lib/documents.js';

/* ------------------------------------------------------------------ */
/* URL helpers                                                         */
/* ------------------------------------------------------------------ */

/** Returns `url` with `param` set to `value`. */
export function withParam(url, param, value) {
    const parsed = new URL(url);
    parsed.searchParams.set(param, String(value));
    return parsed.toString();
}

/** Reads an integer query parameter, defaulting to `fallback`. */
export function readParam(url, param, fallback = 1) {
    try {
        const value = Number.parseInt(new URL(url).searchParams.get(param) ?? '', 10);
        return Number.isFinite(value) ? value : fallback;
    } catch {
        return fallback;
    }
}

/** Extracts a numeric id from a detail URL such as `/procurementdetails/406`. */
export function idFromUrl(url, patterns = [/\/(\d{2,})(?:\D|$)/, /[?&]id=(\d+)/i, /[?&]tender_?id=(\d+)/i]) {
    if (!url) return null;
    for (const pattern of patterns) {
        const match = url.match(pattern);
        if (match) return match[1];
    }
    return null;
}

/* ------------------------------------------------------------------ */
/* Listing helpers                                                     */
/* ------------------------------------------------------------------ */

/** First non-document link inside a row — the tender's detail page. */
export function detailUrlFromRow($, $row, baseUrl, detailLinkSelector) {
    const candidates = detailLinkSelector && $row.find(detailLinkSelector).length
        ? $row.find(detailLinkSelector)
        : $row.find('a[href]');

    let found = null;
    candidates.each((_, element) => {
        if (found) return;
        const node = $(element);
        const url = absoluteUrl(node.attr('href'), baseUrl);
        if (!url) return;
        if (looksLikeDocument(url, node.text())) return;
        found = url;
    });
    return found;
}

/**
 * Turns a listing table into RawItems.
 *
 * @param {object} options
 * @param {string} [options.tableSelector]
 * @param {Record<string,string>} [options.headerOverrides]
 * @param {Record<number,string>} [options.columnMap]
 * @param {string} [options.detailLinkSelector]
 * @param {(item, context) => void} [options.decorate] Adapter-specific post-processing.
 */
export function buildListItems(ctx, options = {}) {
    const { $, request, adapter } = ctx;
    const {
        tableSelector,
        headerOverrides,
        columnMap,
        detailLinkSelector,
        decorate,
    } = options;

    const rows = extractTableRows($, { tableSelector, headerOverrides, columnMap });

    return rows.map(({ values, cells, $row }) => {
        const detailUrl = detailUrlFromRow($, $row, adapter.baseUrl, detailLinkSelector);

        const item = {
            ...values,
            detailUrl,
            sourceUrl: request.url,
            province: values.province ?? adapter.province,
            country: values.country ?? adapter.country ?? 'Pakistan',
        };

        // Documents linked directly from the listing row (very common on the
        // provincial portals, where the notice PDF is the only artefact).
        const rowDocuments = extractDocuments($, $row, adapter.baseUrl);
        if (rowDocuments.length) item._rowDocuments = rowDocuments;

        if (!item.tenderId) item.tenderId = idFromUrl(detailUrl) ?? null;
        if (!item.title && cells.length) {
            // Fall back to the longest cell, which is the title on portals
            // that ship an unlabelled grid.
            const longest = cells.reduce((best, cell) => (cell.length > best.length ? cell : best), '');
            if (longest.length > 15) item.title = longest;
        }

        if (decorate) decorate(item, { $, $row, cells, ctx });
        return item;
    }).filter((item) => item.title || item.referenceNumber || item.detailUrl);
}

/**
 * Default `?page=N` pagination: advance while the current page yielded rows.
 * Returns an empty array when the listing is exhausted.
 */
export function nextPageUrls(ctx, items, { param = 'page', maxPages = 200 } = {}) {
    const { $, request } = ctx;
    if (!items.length) return [];

    // Prefer an explicit "next" control when the portal renders one.
    const explicit = $('a[rel="next"], li.next > a, .pagination a')
        .filter((_, element) => /^(next|›|»|>|next\s*»?)$/i.test(cleanText($(element).text()) ?? ''))
        .first();

    if (explicit.length) {
        const url = absoluteUrl(explicit.attr('href'), request.url);
        if (url && url !== request.url) return [url];
    }

    const current = readParam(request.url, param, 1);
    if (current >= maxPages) return [];
    return [withParam(request.url, param, current + 1)];
}

/* ------------------------------------------------------------------ */
/* Detail helpers                                                      */
/* ------------------------------------------------------------------ */

const DESCRIPTION_SELECTORS = [
    '.tender-description', '.tender_description', '#description', '.description',
    '.detail-description', '.scope-of-work', '.tender-detail-body', '.card-body p',
];

/**
 * Generic detail-page reader: label/value pairs, a description block, public
 * document links, contact fields and outbound procurement links.
 *
 * @param {object} options
 * @param {string} [options.scopeSelector] Container to restrict extraction to.
 * @param {string[]} [options.externalHosts] Hosts kept in `externalLinks`.
 */
export function buildDetailPatch(ctx, options = {}) {
    const { $, request, adapter } = ctx;
    const { scopeSelector, externalHosts = [] } = options;

    // Pick the richest matching container rather than the first one: on
    // Bootstrap-based portals the first `.container` is usually the navbar.
    let scope = $.root();
    if (scopeSelector) {
        let bestLength = 0;
        $(scopeSelector).each((_, element) => {
            const node = $(element);
            const length = (node.text() ?? '').length;
            if (length > bestLength) {
                bestLength = length;
                scope = node;
            }
        });
        // A container that holds almost nothing is not the content area.
        if (bestLength < 200) scope = $.root();
    }

    const patch = extractLabelledValues($, scope);

    if (!patch.description) {
        for (const selector of DESCRIPTION_SELECTORS) {
            const text = cleanBlock(scope.find(selector).first().text());
            if (text && text.length > 30) {
                patch.description = text;
                break;
            }
        }
    }

    // Document links often sit in a header/action bar outside the main content
    // container, so fall back to the whole page when the scope yields nothing.
    let documents = extractDocuments($, scope, request.url);
    if (!documents.length && scope !== $.root()) documents = extractDocuments($, $.root(), request.url);
    if (documents.length) patch._detailDocuments = documents;

    const external = extractExternalLinks($, scope, request.url, { hosts: externalHosts });
    if (external.length) patch.externalLinks = external;

    if (!patch.contactEmail) {
        const mailto = scope.find('a[href^="mailto:"]').first().attr('href');
        if (mailto) patch.contactEmail = cleanText(mailto.replace(/^mailto:/i, '').split('?')[0]);
    }

    patch.detailUrl = request.url;
    if (!patch.tenderId) {
        const id = idFromUrl(request.url);
        if (id) patch.tenderId = id;
    }
    if (!patch.province) patch.province = adapter.province;

    return patch;
}

/**
 * Merges list-page and detail-page raw items and resolves the four document
 * buckets. List values win only where the detail page is silent.
 */
export function mergeRawItem(listItem, detailPatch = {}) {
    const merged = { ...listItem };

    for (const [key, value] of Object.entries(detailPatch)) {
        if (value == null || value === '') continue;
        if (key.startsWith('_')) continue;
        // The detail page is authoritative for descriptive/commercial fields.
        merged[key] = value;
    }

    const documents = mergeDocuments(listItem._rowDocuments, detailPatch._detailDocuments);
    const buckets = bucketDocuments(documents);

    merged.documents = buckets.documents;
    merged.corrigenda = buckets.corrigenda;
    merged.evaluationReports = buckets.evaluationReports;
    merged.contractAwards = buckets.contractAwards;

    delete merged._rowDocuments;
    delete merged._detailDocuments;

    return merged;
}

/** Resolves document buckets for an item that has no detail page visit. */
export function finalizeWithoutDetail(listItem) {
    return mergeRawItem(listItem, {});
}

/** Builds start requests for a list of paths on the adapter's base URL. */
export function startRequestsFromPaths(adapter, paths, userData = {}) {
    return paths.map((path) => ({
        url: new URL(path, adapter.baseUrl).toString(),
        userData: { label: 'LIST', source: adapter.key, ...userData },
    }));
}

export { extractTableRows, extractDocuments, bucketDocuments, mergeDocuments };
