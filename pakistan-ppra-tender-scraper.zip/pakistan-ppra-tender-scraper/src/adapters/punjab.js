/**
 * Punjab PPRA — PPRA Services Portal / Punjab e-Procurement.
 *
 *   Listing : https://eproc.punjab.gov.pk/ActiveTenders.aspx
 *             https://eproc.punjab.gov.pk/ArchiveTenders.aspx
 *   EPADS   : https://punjab.eprocure.gov.pk (public notices mirror)
 *
 * This is an ASP.NET WebForms GridView: pagination happens through
 * `__doPostBack('...','Page$N')` with a ViewState round-trip, so this is the
 * one adapter that needs a real browser. Everything else is parsed from the
 * rendered DOM with the same Cheerio helpers as the other sources.
 */

import {
    buildDetailPatch,
    buildListItems,
    startRequestsFromPaths,
} from './base.js';

const HEADER_OVERRIDES = {
    'tender no': 'referenceNumber',
    'tender id': 'tenderId',
    'tender title': 'title',
    'procuring agency': 'procuringAgency',
    'department name': 'department',
    'tender category': 'procurementCategory',
    'advertisement date': 'publishedDate',
    'closing date': 'closingDate',
    'opening date': 'openingDate',
    'tender status': 'status',
};

const adapter = {
    key: 'punjab',
    name: 'Punjab PPRA / Punjab e-Procurement',
    province: 'Punjab',
    country: 'Pakistan',
    baseUrl: 'https://eproc.punjab.gov.pk',
    engine: 'playwright',
    descendingByPublishedDate: true,

    crawlerOptions: {
        maxConcurrency: 2,
        navigationTimeoutSecs: 90,
        requestHandlerTimeoutSecs: 300,
    },

    startRequests(input) {
        const paths = ['/ActiveTenders.aspx'];
        if (input.activeOnly === false) paths.push('/ArchiveTenders.aspx');
        return startRequestsFromPaths(adapter, paths);
    },

    parseList(ctx) {
        const items = buildListItems(ctx, {
            headerOverrides: HEADER_OVERRIDES,
            // GridView row links are postbacks, not hrefs; detail navigation is
            // handled in-page by `openDetail` below where a URL is available.
            decorate(item, { $row }) {
                const onclick = $row.attr('onclick') ?? $row.find('a').attr('href') ?? '';
                if (/__doPostBack/.test(onclick) && !item.detailUrl) {
                    // Record the postback target so a maintainer can wire a
                    // detail visit later; never fabricate a URL.
                    item._postback = onclick;
                }
            },
        });

        // Pagination is a postback, so no `nextUrls` — see `gotoNextPage`.
        return { items, nextUrls: [] };
    },

    /**
     * Clicks the GridView pager. Returns false when there is no further page,
     * which ends the in-page pagination loop for this request.
     */
    async gotoNextPage({ page, pageNumber, log }) {
        const target = `Page$${pageNumber}`;
        const link = page.locator(`a[href*="${target}'"], a[href*='${target}"'], a[href*="${target}"]`).first();

        if (!(await link.count())) {
            // Fall back to a numbered pager link.
            const numbered = page.locator(`.pagination a, table a`).filter({ hasText: new RegExp(`^\\s*${pageNumber}\\s*$`) }).first();
            if (!(await numbered.count())) return false;
            await Promise.all([
                page.waitForLoadState('networkidle', { timeout: 60000 }).catch(() => {}),
                numbered.click(),
            ]);
            log.debug(`Punjab: moved to page ${pageNumber} via numbered pager.`);
            return true;
        }

        await Promise.all([
            page.waitForLoadState('networkidle', { timeout: 60000 }).catch(() => {}),
            link.click(),
        ]);
        log.debug(`Punjab: moved to page ${pageNumber} via ${target}.`);
        return true;
    },

    parseDetail(ctx) {
        return buildDetailPatch(ctx, {
            scopeSelector: 'form, #form1, .container',
            externalHosts: ['eprocure.gov.pk', 'punjab.gov.pk'],
        });
    },
};

export default adapter;
