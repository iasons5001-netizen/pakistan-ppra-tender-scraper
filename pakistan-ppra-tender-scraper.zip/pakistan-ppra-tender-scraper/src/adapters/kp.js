/**
 * Khyber Pakhtunkhwa PPRA (KPPRA).
 *
 *   Listing : http://www.kppra.gov.pk/kppra/activetenders
 *             http://www.kppra.gov.pk/kppra/tenders
 *   Mirror  : https://kppra.kp.gov.pk/page_type/tenders
 *
 * Operational note (verified 2026-09-07): the HTTPS host issues a 302 back to
 * HTTP, so the plain-HTTP origin is used as the canonical base to avoid a
 * redirect loop. Several listing paths are attempted; ones that 404 are
 * skipped without retries rather than failing the source.
 */

import {
    buildDetailPatch,
    buildListItems,
    nextPageUrls,
    startRequestsFromPaths,
} from './base.js';

/**
 * Verified 2026-09-07 — the KPPRA active-tenders grid ships these columns:
 *   Tender No | Tender Description | Procurement Entity |
 *   Date of Advertisement | Closing Date | Tender/EOI | Bidding Documents | Action
 * "Tender Description" is the notice title, not a long description.
 */
const HEADER_OVERRIDES = {
    'tender no': 'referenceNumber',
    'tender id': 'tenderId',
    'tender description': 'title',
    'tender title': 'title',
    'title of tender': 'title',
    subject: 'title',
    'procurement entity': 'procuringAgency',
    'procuring agency': 'procuringAgency',
    'department name': 'department',
    department: 'department',
    'tender type': 'noticeType',
    category: 'procurementCategory',
    'published date': 'publishedDate',
    'advertisement date': 'publishedDate',
    'closing date': 'closingDate',
    'last date': 'closingDate',
    'opening date': 'openingDate',
    status: 'status',
    district: 'city',
};

const adapter = {
    key: 'kp',
    name: 'Khyber Pakhtunkhwa PPRA (KPPRA)',
    province: 'Khyber Pakhtunkhwa',
    country: 'Pakistan',
    baseUrl: 'http://www.kppra.gov.pk',
    engine: 'cheerio',
    descendingByPublishedDate: true,

    crawlerOptions: {
        maxConcurrency: 3,
        ignoreSslErrors: true,
    },

    startRequests(input) {
        const paths = ['/kppra/activetenders'];
        if (input.activeOnly === false) paths.push('/kppra/tenders', '/kppra/archivetenders');
        const requests = startRequestsFromPaths(adapter, paths);

        // Secondary public mirror on the KP government platform.
        requests.push({
            url: 'https://kppra.kp.gov.pk/page_type/tenders',
            userData: { label: 'LIST', source: adapter.key, surface: 'kp-gov-mirror' },
        });

        return requests;
    },

    parseList(ctx) {
        const items = buildListItems(ctx, {
            headerOverrides: HEADER_OVERRIDES,
            decorate(item, { $row }) {
                // KPPRA opens tender details in a JavaScript modal
                // (`details(33310)`) rather than at a public URL, so no detail
                // URL is fabricated. The internal id is kept for traceability
                // and the notice PDF is already captured as a row document.
                const trigger = $row.find('[onclick*="details("]').attr('onclick');
                const match = trigger?.match(/details\((\d+)\)/);
                if (match) item.portalRecordId = match[1];
            },
        });
        return { items, nextUrls: nextPageUrls(ctx, items, { param: 'page' }) };
    },

    parseDetail(ctx) {
        return buildDetailPatch(ctx, {
            scopeSelector: '.container, main, #content, article',
            externalHosts: ['kppra.gov.pk', 'kp.gov.pk', 'eprocure.gov.pk'],
        });
    },
};

export default adapter;
