/**
 * Sindh PPRA (SPPRA) — PPMS public portal and the classic tender listings.
 *
 *   PPMS    : https://ppms.pprasindh.gov.pk/PPMS/public/portal/notice-inviting-tender
 *   Classic : https://e.pprasindh.gov.pk/tenderlst
 *             https://www.pprasindh.gov.pk/tendersdepartment.php
 *
 * Operational note (verified 2026-09-07): the PPMS host currently serves a
 * self-signed TLS certificate, so `ignoreSslErrors` is enabled for this source
 * only. That is a transport-level tolerance for a broken government cert — it
 * does not bypass any authentication or access control.
 */

import {
    buildDetailPatch,
    buildListItems,
    nextPageUrls,
} from './base.js';

const HEADER_OVERRIDES = {
    'tender no': 'referenceNumber',
    'tender ref no': 'referenceNumber',
    'nit no': 'referenceNumber',
    'tender title': 'title',
    'title of tender': 'title',
    'procuring agency': 'procuringAgency',
    'name of procuring agency': 'procuringAgency',
    department: 'department',
    'tender type': 'noticeType',
    'date of advertisement': 'publishedDate',
    'advertisement date': 'publishedDate',
    'closing date': 'closingDate',
    'last date of submission': 'closingDate',
    'opening date': 'openingDate',
    status: 'status',
    city: 'city',
};

const adapter = {
    key: 'sindh',
    name: 'Sindh PPRA (SPPRA) / PPMS',
    province: 'Sindh',
    country: 'Pakistan',
    baseUrl: 'https://ppms.pprasindh.gov.pk',
    engine: 'cheerio',
    descendingByPublishedDate: true,

    crawlerOptions: {
        maxConcurrency: 3,
        // See the TLS note in the module docblock.
        ignoreSslErrors: true,
    },

    startRequests() {
        return [
            {
                url: 'https://ppms.pprasindh.gov.pk/PPMS/public/portal/notice-inviting-tender',
                userData: { label: 'LIST', source: adapter.key, surface: 'ppms' },
            },
            {
                url: 'https://e.pprasindh.gov.pk/tenderlst',
                userData: { label: 'LIST', source: adapter.key, surface: 'classic' },
            },
        ];
    },

    parseList(ctx) {
        const items = buildListItems(ctx, {
            headerOverrides: HEADER_OVERRIDES,
            decorate(item, { ctx: inner }) {
                item.sourceUrl = inner.request.url;
                if (!item.province) item.province = adapter.province;
            },
        });

        // Both surfaces paginate with `?page=N`; the classic listing also
        // renders an explicit Next control, which nextPageUrls prefers.
        return { items, nextUrls: nextPageUrls(ctx, items, { param: 'page' }) };
    },

    parseDetail(ctx) {
        return buildDetailPatch(ctx, {
            scopeSelector: '.container, main, #content, .panel',
            externalHosts: ['pprasindh.gov.pk', 'sindh.gov.pk'],
        });
    },
};

export default adapter;
