/**
 * Adapter registry.
 *
 * Adding a source is a two-step change: create `src/adapters/<key>.js`
 * following the contract in `base.js`, then register it here and add its key
 * to the `sources` enum in `.actor/input_schema.json`. Nothing else — the
 * normalized dataset contract is unaffected.
 */

import ajk from './ajk.js';
import balochistan from './balochistan.js';
import federal from './federal.js';
import gb from './gb.js';
import kp from './kp.js';
import punjab from './punjab.js';
import sindh from './sindh.js';

export const ADAPTERS = {
    federal,
    punjab,
    sindh,
    kp,
    balochistan,
    ajk,
    gb,
};

export const ALL_SOURCE_KEYS = Object.keys(ADAPTERS);

/**
 * Resolves the requested source keys to adapters.
 * Unknown keys are reported rather than silently dropped.
 */
export function resolveAdapters(sources) {
    const requested = Array.isArray(sources) && sources.length ? sources : ALL_SOURCE_KEYS;

    const adapters = [];
    const unknown = [];

    for (const key of requested) {
        const normalized = String(key).trim().toLowerCase();
        if (ADAPTERS[normalized]) adapters.push(ADAPTERS[normalized]);
        else unknown.push(key);
    }

    return { adapters, unknown };
}

export default ADAPTERS;
