/**
 * Federal PPRA — EPMS public tender portal (the public face of EPADS).
 *
 * Verified 2026-09-07:
 *   Listing : https://epms.ppra.gov.pk/public/tenders/active-tenders?page=N
 *   Columns : Sr | Tender No | Tender Details | Organization Details |
 *             Status | Advertised | Closing | Actions
 *   Paging  : `?page=N`, "Page 1 of 38" indicator.
 *
 * Public only: no login, no CAPTCHA solving, no access-controlled area.
 */

import {
    buildDetailPatch,
    buildListItems,
    nextPageUrls,
    startRequestsFromPaths,
} from './base.js';
import { cleanText } from '../lib/normalize.js';
import { toIso } from '../lib/dates.js';

/** "Corrigendum #2 Issued On: September 07, 2026 01:11 PM Closing Date: September 10, 2026" */
const CORRIGENDUM_RE = /Corrigendum\s*#?\s*(\d+)\s*(?:Issued\s*On\s*:?\s*([A-Za-z]+\s+\d{1,2},\s*\d{4}(?:\s+\d{1,2}:\d{2}\s*[AP]M)?))?\s*(?:Closing\s*Date\s*:?\s*([A-Za-z]+\s+\d{1,2},\s*\d{4}))?/gi;

const HEADER_OVERRIDES = {
    'tender no': 'referenceNumber',
    'tender details': 'title',
    'organization details': 'procuringAgency',
    advertised: 'publishedDate',
    closing: 'closingDate',
    status: 'status',
};

const adapter = {
    key: 'federal',
    name: 'Federal PPRA (EPMS / EPADS)',
    province: 'Federal',
    country: 'Pakistan',
    baseUrl: 'https://epms.ppra.gov.pk',
    engine: 'cheerio',
    descendingByPublishedDate: true,

    crawlerOptions: {
        maxConcurrency: 5,
    },

    startRequests(input) {
        // The portal exposes an "active tenders" view publicly. When the user
        // explicitly wants closed notices too, the archive view is added; if
        // that path is absent the request 404s and is skipped without retries.
        const paths = ['/public/tenders/active-tenders'];
        if (input.activeOnly === false) paths.push('/public/tenders/archive-tenders');
        return startRequestsFromPaths(adapter, paths);
    },

    parseList(ctx) {
        const items = buildListItems(ctx, {
            headerOverrides: HEADER_OVERRIDES,
            decorate(item, { $, $row }) {
                // The EPMS grid packs several logical fields into two cells, so
                // the flat cell text produced by the generic reader is refined
                // here. Cells are located by their own markup first and by
                // column position only as a fallback, which keeps the adapter
                // working when a column is inserted.
                const cellWith = (selector, fallbackIndex) => {
                    const found = $row.find('td').filter((_, element) => $(element).find(selector).length > 0).first();
                    return found.length ? found : $row.find('td').eq(fallbackIndex);
                };

                // --- Tender Details cell: title, description lines, category ---
                const detailsCell = cellWith('div > strong', 2);
                const detailsBody = detailsCell.children('div').first();

                const title = cleanText(detailsCell.find('strong').first().text());
                if (title) item.title = title;

                const descriptionLines = [];
                detailsBody.children('small').each((_, element) => {
                    const text = cleanText($(element).text());
                    if (text && !descriptionLines.includes(text)) descriptionLines.push(text);
                });
                if (descriptionLines.length) item.description = descriptionLines.join('\n');

                // The first non-muted badge is the procurement category; the
                // muted ones repeat quantities already captured above.
                detailsCell.find('.badge').each((_, element) => {
                    if (item.procurementCategory) return;
                    const node = $(element);
                    if ((node.attr('class') ?? '').includes('text-muted')) return;
                    item.procurementCategory = cleanText(node.text());
                });

                // --- Organization Details cell: agency, department, location ---
                // The first <small> carries the full legal name of the procuring
                // entity; the `.tender-org` span carries its short/office name
                // (identical on many rows, in which case `office` stays null).
                const orgCell = cellWith('.tender-org', 3);
                const fullName = cleanText(orgCell.find('small').first().text());
                const shortName = cleanText(orgCell.find('.tender-org').first().text());

                if (fullName) item.procuringAgency = fullName;
                else if (shortName) item.procuringAgency = shortName;

                if (shortName && fullName && shortName !== fullName) item.office = shortName;

                orgCell.find('small').each((_, element) => {
                    const text = cleanText($(element).text());
                    if (!text || !text.includes(' - ')) return;
                    const [city, country] = text.split(' - ').map((part) => part.trim());
                    if (city) item.city = city.replace(/\.$/, '');
                    if (country) item.country = country;
                });

                // --- Status cell: first badge only (a row can carry two) ---
                const statusCell = cellWith('.tender-badge', 4);
                const status = cleanText(statusCell.find('.tender-badge, .badge').first().text());
                if (status) item.status = status;

                // The tender number doubles as the portal's own identifier.
                if (!item.tenderId && item.referenceNumber) item.tenderId = item.referenceNumber;
            },
        });

        return { items, nextUrls: nextPageUrls(ctx, items, { param: 'page' }) };
    },

    parseDetail(ctx) {
        const { $, request } = ctx;

        const patch = buildDetailPatch(ctx, {
            scopeSelector: 'main, .container, #content',
            externalHosts: ['eprocure.gov.pk', 'ppra.gov.pk'],
        });

        // EPMS publishes its corrigendum history as text, not as files. The
        // entries are recorded so a bidder sees that the notice was amended
        // and when; each anchors back to the section of the detail page that
        // states it. No document URL is invented.
        const history = cleanText($('body').text())?.split(/Corrigendum\s+History/i)[1];
        if (history) {
            const entries = [];
            CORRIGENDUM_RE.lastIndex = 0;
            let match = CORRIGENDUM_RE.exec(history);
            while (match) {
                entries.push({
                    name: `Corrigendum #${match[1]}`,
                    type: 'corrigendum',
                    url: `${request.url}#corrigendum-${match[1]}`,
                    issuedOn: toIso(match[2]) ?? cleanText(match[2]),
                    revisedClosingDate: toIso(match[3]) ?? cleanText(match[3]),
                });
                match = CORRIGENDUM_RE.exec(history);
            }
            if (entries.length) {
                patch._detailDocuments = [...(patch._detailDocuments ?? []), ...entries];
            }
        }

        return patch;
    },
};

export default adapter;
