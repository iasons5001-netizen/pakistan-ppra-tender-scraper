/**
 * Azad Jammu & Kashmir PPRA.
 *
 *   Portal : https://www.ajkppra.gov.pk
 *
 * The AJK portal is a small server-rendered PHP site whose tender listing has
 * moved between paths over time, so several candidate listing paths are
 * requested; anything that 404s is skipped without retries. Table headers are
 * resolved through the shared alias map, which keeps the adapter working
 * across the portal's periodic column renames.
 */

import {
    buildDetailPatch,
    buildListItems,
    nextPageUrls,
    startRequestsFromPaths,
} from './base.js';

/**
 * Verified 2026-09-07 — the AJK PPRA listing ships these columns:
 *   Procurement | Procurement Title | Publishing Date | Closing Date |
 *   Department | Procuring Agency | Download
 * The first column packs the notice type and the portal's own id on two lines.
 */
const HEADER_OVERRIDES = {
    'procurement title': 'title',
    'publishing date': 'publishedDate',
    'procuring agency': 'procuringAgency',
    'tender no': 'referenceNumber',
    'tender title': 'title',
    'name of work': 'title',
    subject: 'title',
    'procuring agency': 'procuringAgency',
    department: 'department',
    'tender type': 'noticeType',
    'date of advertisement': 'publishedDate',
    'publishing date': 'publishedDate',
    'closing date': 'closingDate',
    'last date': 'closingDate',
    'opening date': 'openingDate',
    status: 'status',
    district: 'city',
};

const adapter = {
    key: 'ajk',
    name: 'AJK PPRA',
    province: 'Azad Jammu & Kashmir',
    country: 'Pakistan',
    baseUrl: 'https://www.ajkppra.gov.pk',
    engine: 'cheerio',
    descendingByPublishedDate: true,

    crawlerOptions: {
        maxConcurrency: 2,
        ignoreSslErrors: true,
    },

    startRequests(input) {
        // `advertisements.php` is the full active listing; the homepage table
        // carries the newest notices and is kept as a fallback surface.
        const paths = ['/advertisements.php', '/index.php'];
        if (input.activeOnly === false) paths.push('/searchadvertisements.php');
        return startRequestsFromPaths(adapter, paths);
    },

    parseList(ctx) {
        const items = buildListItems(ctx, {
            headerOverrides: HEADER_OVERRIDES,
            decorate(item, { $, $row }) {
                // Column 1 holds "Tender Notice" over the portal's record id.
                const first = $row.find('td').first();
                const lines = ($.html(first) ?? '')
                    .replace(/<br\s*\/?>/gi, '\n')
                    .replace(/<[^>]+>/g, ' ')
                    .split('\n')
                    .map((line) => line.replace(/\s+/g, ' ').trim())
                    .filter(Boolean);

                for (const line of lines) {
                    if (/^\d+$/.test(line)) item.tenderId ??= line;
                    else item.noticeType ??= line;
                }
            },
        });
        return { items, nextUrls: nextPageUrls(ctx, items, { param: 'page', maxPages: 100 }) };
    },

    parseDetail(ctx) {
        return buildDetailPatch(ctx, {
            scopeSelector: '.container, #content, main, table',
            externalHosts: ['ajkppra.gov.pk', 'ajk.gov.pk'],
        });
    },
};

export default adapter;
