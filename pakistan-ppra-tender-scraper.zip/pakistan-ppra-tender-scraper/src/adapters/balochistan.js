/**
 * Balochistan PPRA (BPPRA) and the Balochistan ePPS surface.
 *
 *   Search  : http://bppra.gob.pk/searchnewTender.php
 *   By dept : http://bppra.gob.pk/department_tenders.php
 *   ePPS    : https://eprocurebalochistan.gob.pk (public notices)
 *
 * The BPPRA site is a server-rendered PHP application, so CheerioCrawler is
 * sufficient. Paths that are not live 404 and are skipped without retries.
 */

import {
    buildDetailPatch,
    buildListItems,
    nextPageUrls,
    startRequestsFromPaths,
} from './base.js';

const HEADER_OVERRIDES = {
    'tender no': 'referenceNumber',
    'tender id': 'tenderId',
    'tender title': 'title',
    'name of work': 'title',
    'description of work': 'title',
    'procuring agency': 'procuringAgency',
    department: 'department',
    'tender type': 'noticeType',
    'procurement category': 'procurementCategory',
    'published on': 'publishedDate',
    'advertisement date': 'publishedDate',
    'publish date': 'publishedDate',
    'closing date': 'closingDate',
    'submission date': 'closingDate',
    'opening date': 'openingDate',
    status: 'status',
    district: 'city',
};

const adapter = {
    key: 'balochistan',
    name: 'Balochistan PPRA (BPPRA) / ePPS',
    province: 'Balochistan',
    country: 'Pakistan',
    baseUrl: 'http://bppra.gob.pk',
    engine: 'cheerio',
    descendingByPublishedDate: true,

    crawlerOptions: {
        maxConcurrency: 3,
        ignoreSslErrors: true,
    },

    startRequests(input) {
        const paths = ['/searchnewTender.php', '/tenders.php'];
        if (input.activeOnly === false) paths.push('/department_tenders.php');
        const requests = startRequestsFromPaths(adapter, paths);

        requests.push({
            url: 'https://eprocurebalochistan.gob.pk/',
            userData: { label: 'LIST', source: adapter.key, surface: 'epps' },
        });

        return requests;
    },

    parseList(ctx) {
        const items = buildListItems(ctx, { headerOverrides: HEADER_OVERRIDES });
        return { items, nextUrls: nextPageUrls(ctx, items, { param: 'page' }) };
    },

    parseDetail(ctx) {
        return buildDetailPatch(ctx, {
            scopeSelector: '.container, #content, main, table',
            externalHosts: ['bppra.gob.pk', 'balochistan.gob.pk'],
        });
    },
};

export default adapter;
