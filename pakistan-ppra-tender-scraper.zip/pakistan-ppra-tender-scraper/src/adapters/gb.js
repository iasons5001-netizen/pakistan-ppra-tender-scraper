/**
 * Gilgit-Baltistan PPRA.
 *
 * Verified 2026-09-07:
 *   Listing : https://www.gbppra.gov.pk/procurements/{typeId}?page=N
 *   Columns : S# | Title | Type | Department | Opening Date | Closing Date |
 *             Tender Document | Tender Notice | View
 *   Detail  : https://www.gbppra.gov.pk/procurementdetails/{id}
 *   Paging  : `?page=N`, "Showing 1 to 10 of N results"
 *
 * Field note: the listing's "Opening Date" column is mapped to `openingDate`
 * and NOT to `publishedDate`. The portal does not label an advertisement date
 * on the listing, and guessing one would put an invented value into a
 * commercial record. `publishedDate` is filled only when the detail page
 * states it.
 */

import {
    buildDetailPatch,
    buildListItems,
    nextPageUrls,
    readParam,
    withParam,
} from './base.js';

/** Highest `?page=N` value referenced by the pager on the current page. */
function lastPageNumber($, currentUrl) {
    let last = 1;
    $('a[href*="page="]').each((_, element) => {
        const href = $(element).attr('href');
        if (!href) return;
        try {
            const page = Number.parseInt(new URL(href, currentUrl).searchParams.get('page') ?? '', 10);
            if (Number.isFinite(page) && page > last) last = page;
        } catch {
            /* ignore malformed pager links */
        }
    });
    return last;
}

/** Procurement type ids exposed by the public listing. */
const TYPE_IDS = [1, 2, 3, 4, 5];

const HEADER_OVERRIDES = {
    title: 'title',
    type: 'noticeType',
    department: 'department',
    'opening date': 'openingDate',
    'closing date': 'closingDate',
    'tender document': '_documentColumn',
    'tender notice': '_noticeColumn',
    view: '_viewColumn',
};

const adapter = {
    key: 'gb',
    name: 'Gilgit-Baltistan PPRA',
    province: 'Gilgit-Baltistan',
    country: 'Pakistan',
    baseUrl: 'https://www.gbppra.gov.pk',
    engine: 'cheerio',
    descendingByPublishedDate: false,

    crawlerOptions: {
        maxConcurrency: 4,
    },

    startRequests() {
        return TYPE_IDS.map((typeId) => ({
            url: `${adapter.baseUrl}/procurements/${typeId}`,
            userData: { label: 'LIST', source: adapter.key, typeId },
        }));
    },

    parseList(ctx) {
        const items = buildListItems(ctx, {
            headerOverrides: HEADER_OVERRIDES,
            detailLinkSelector: 'a[href*="procurementdetails"]',
            decorate(item) {
                // The three link columns are placeholders in the header map;
                // their actual links are already collected as row documents.
                delete item._documentColumn;
                delete item._noticeColumn;
                delete item._viewColumn;
                if (!item.procuringAgency && item.department) item.procuringAgency = item.department;
            },
        });

        // The GB listing is ordered oldest-first, so page 1 is historical and
        // open tenders sit on the LAST pages. When only active tenders are
        // wanted, jump to the final page and walk backwards; otherwise page
        // forward normally.
        const { $, request, input } = ctx;
        if (input?.activeOnly !== false) {
            const current = readParam(request.url, 'page', 0);
            if (!current) {
                // Page 1 is used only to read the pager: its rows are years old
                // and would otherwise consume the whole per-source budget.
                const last = lastPageNumber($, request.url);
                if (last > 1) return { items: [], nextUrls: [withParam(request.url, 'page', last)] };
                return { items, nextUrls: [] };
            }
            return { items, nextUrls: current > 1 ? [withParam(request.url, 'page', current - 1)] : [] };
        }

        return { items, nextUrls: nextPageUrls(ctx, items, { param: 'page' }) };
    },

    parseDetail(ctx) {
        return buildDetailPatch(ctx, {
            scopeSelector: '.container, main, #content, .card',
            externalHosts: ['gbppra.gov.pk', 'gbit.gov.pk', 'gilgitbaltistan.gov.pk'],
        });
    },
};

export default adapter;
