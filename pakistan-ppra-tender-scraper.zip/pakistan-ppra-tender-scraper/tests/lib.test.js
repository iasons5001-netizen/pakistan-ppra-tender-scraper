/**
 * Unit tests for the pure library layer. Run with `npm test` (Node >= 18).
 * These deliberately avoid the network: the crawler layer is exercised
 * against the live portals, the contract layer is exercised here.
 */

import assert from 'node:assert/strict';
import test from 'node:test';
import * as cheerio from 'cheerio';

import { daysUntil, parseDate, withinRange } from '../src/lib/dates.js';
import {
    cleanText,
    extractLabelledValues,
    extractTableRows,
    normalizeTender,
    parseInteger,
    parsePercent,
    resolveField,
} from '../src/lib/normalize.js';
import { bucketDocuments, classifyDocument, extractDocuments } from '../src/lib/documents.js';
import { evaluateTender, isActive, isRestricted, sortTenders } from '../src/lib/filters.js';
import { Deduplicator, dedupeKey } from '../src/lib/deduplicate.js';
import { resolveAdapters, ALL_SOURCE_KEYS } from '../src/adapters/index.js';

const ADAPTER = {
    key: 'federal',
    name: 'Federal PPRA (EPMS / EPADS)',
    province: 'Federal',
    country: 'Pakistan',
    baseUrl: 'https://epms.ppra.gov.pk',
};

/* ---------------------------------------------------------------- dates */

test('parseDate handles the formats Pakistani portals actually publish', () => {
    assert.equal(parseDate('24/09/2026').iso, '2026-09-24');
    assert.equal(parseDate('24-09-2026').iso, '2026-09-24');
    assert.equal(parseDate('2026-09-24').iso, '2026-09-24');
    assert.equal(parseDate('24 Sep 2026').iso, '2026-09-24');
    assert.equal(parseDate('24-September-2026').iso, '2026-09-24');
    assert.equal(parseDate('Sep 24, 2026').iso, '2026-09-24');
    assert.equal(parseDate('24/09/2026 02:00 PM').iso, '2026-09-24T14:00:00+05:00');
    assert.equal(parseDate('24 Sep 2026 11:30').iso, '2026-09-24T11:30:00+05:00');
});

test('parseDate reads ambiguous numeric dates day-first, month-first only when forced', () => {
    assert.equal(parseDate('03/09/2026').iso, '2026-09-03', 'day-first is the Pakistani convention');
    assert.equal(parseDate('09/24/2026').iso, '2026-09-24', 'second component > 12 forces month-first');
});

test('parseDate returns null instead of guessing', () => {
    assert.equal(parseDate('To be announced'), null);
    assert.equal(parseDate('N/A'), null);
    assert.equal(parseDate(''), null);
    assert.equal(parseDate(null), null);
    assert.equal(parseDate('32/13/2026'), null);
});

test('daysUntil and withinRange behave at the boundaries', () => {
    const now = new Date('2026-09-07T09:00:00+05:00');
    assert.equal(daysUntil('2026-09-07', now), 0, 'closing today is still zero days left');
    assert.equal(daysUntil('2026-09-10', now), 3);
    assert.ok(daysUntil('2026-09-01', now) < 0);

    assert.equal(withinRange('2026-09-07', '2026-09-01', '2026-09-30'), true);
    assert.equal(withinRange('2026-08-31', '2026-09-01', null), false);
    assert.equal(withinRange(null, '2026-09-01', '2026-09-30'), true, 'unknown dates are never dropped by a range');
});

/* ------------------------------------------------------------ normalize */

test('resolveField maps real portal headers onto canonical fields', () => {
    assert.equal(resolveField('Tender No'), 'referenceNumber');
    assert.equal(resolveField('Tender Details'), 'title');
    assert.equal(resolveField('Organization Details'), 'procuringAgency');
    assert.equal(resolveField('Advertised'), 'publishedDate');
    assert.equal(resolveField('Closing'), 'closingDate');
    assert.equal(resolveField('Last Date of Submission'), 'closingDate');
    assert.equal(resolveField('Sr'), null);
});

test('extractTableRows reads the Federal EPMS listing shape', () => {
    const html = `
      <table class="table">
        <tr><th>Sr</th><th>Tender No</th><th>Tender Details</th><th>Organization Details</th>
            <th>Status</th><th>Advertised</th><th>Closing</th><th>Actions</th></tr>
        <tr>
          <td>1</td><td>TS-2026-0091</td>
          <td><a href="/public/tenders/4471">Supply of Agriculture Tool Kits</a></td>
          <td>Ministry of National Food Security</td>
          <td>Published</td><td>01/09/2026</td><td>24/09/2026</td>
          <td><a href="/docs/tender-4471.pdf">Download</a></td>
        </tr>
      </table>`;
    const $ = cheerio.load(html);
    const rows = extractTableRows($, {});

    assert.equal(rows.length, 1);
    assert.equal(rows[0].values.referenceNumber, 'TS-2026-0091');
    assert.equal(rows[0].values.title, 'Supply of Agriculture Tool Kits');
    assert.equal(rows[0].values.procuringAgency, 'Ministry of National Food Security');
    assert.equal(rows[0].values.publishedDate, '01/09/2026');
    assert.equal(rows[0].values.closingDate, '24/09/2026');
});

test('extractLabelledValues reads a two-column detail table', () => {
    const $ = cheerio.load(`
      <table>
        <tr><th>Bid Security</th><td>2% of bid value</td></tr>
        <tr><th>Bid Validity</th><td>90 days</td></tr>
        <tr><th>Procurement Method</th><td>Single Stage Two Envelope</td></tr>
        <tr><th>Contact Person</th><td>Deputy Director (Procurement)</td></tr>
      </table>`);
    const values = extractLabelledValues($);

    assert.equal(values.bidSecurity, '2% of bid value');
    assert.equal(values.bidValidityDays, '90 days');
    assert.equal(values.procurementMethod, 'Single Stage Two Envelope');
    assert.equal(values.contactName, 'Deputy Director (Procurement)');
});

test('cleanText and number helpers do not invent values', () => {
    assert.equal(cleanText('  Supply   of  kits '), 'Supply of kits');
    assert.equal(cleanText('N/A'), null);
    assert.equal(cleanText('---'), null);
    assert.equal(parseInteger('90 days'), 90);
    assert.equal(parseInteger('no value'), null);
    assert.equal(parsePercent('2% of bid value'), 2);
    assert.equal(parsePercent('PKR 250,000'), null);
});

test('normalizeTender produces the full contract and keeps unparsable raw dates', () => {
    const record = normalizeTender({
        referenceNumber: 'TS-2026-0091',
        title: 'Supply of Agriculture Tool Kits',
        procuringAgency: 'Ministry of National Food Security',
        publishedDate: '01/09/2026',
        closingDate: 'On or before Friday',
        bidSecurity: '2% of bid value',
        bidValidityDays: '90 days',
        detailUrl: '/public/tenders/4471',
    }, ADAPTER, { scrapedAt: '2026-09-07T04:00:00.000Z', now: new Date('2026-09-07T09:00:00+05:00') });

    assert.equal(record.source, 'federal');
    assert.equal(record.province, 'Federal');
    assert.equal(record.country, 'Pakistan');
    assert.equal(record.tenderId, 'TS-2026-0091', 'tenderId falls back to the reference number');
    assert.equal(record.publishedDate, '2026-09-01');
    assert.equal(record.closingDate, null, 'unparsable closing date is not invented');
    assert.equal(record.closingDateRaw, 'On or before Friday', 'raw text is preserved');
    assert.equal(record.remainingDays, null);
    assert.equal(record.bidSecurityPercent, 2);
    assert.equal(record.bidValidityDays, 90);
    assert.equal(record.detailUrl, 'https://epms.ppra.gov.pk/public/tenders/4471');
    assert.deepEqual(record.documents, []);
    assert.deepEqual(record.corrigenda, []);
    assert.equal(record.openingDate, null);
    assert.equal(record.sector, null);
    assert.equal(typeof record.scrapedAt, 'string');
});

/* ------------------------------------------------------------ documents */

test('classifyDocument separates the four buckets', () => {
    assert.equal(classifyDocument('Corrigendum-1.pdf'), 'corrigendum');
    assert.equal(classifyDocument('Bid Evaluation Report', '/ber/2026.pdf'), 'evaluation_report');
    assert.equal(classifyDocument('Contract Award Notice'), 'contract_award');
    assert.equal(classifyDocument('Bidding Document'), 'bidding_document');
    assert.equal(classifyDocument('Tender Notice'), 'tender_notice');
    assert.equal(classifyDocument('Annexure-A.pdf'), 'tender_document');
});

test('extractDocuments collects public links only and buckets them', () => {
    const $ = cheerio.load(`
      <div id="docs">
        <a href="/files/bidding-document.pdf">Bidding Document</a>
        <a href="/files/corrigendum-1.pdf">Corrigendum No. 1</a>
        <a href="/files/ber.pdf">Bid Evaluation Report</a>
        <a href="https://epms.ppra.gov.pk/about">About us</a>
        <a href="javascript:void(0)">Print</a>
      </div>`);

    const documents = extractDocuments($, $('#docs'), 'https://epms.ppra.gov.pk');
    assert.equal(documents.length, 3, 'navigation and javascript links are ignored');

    const buckets = bucketDocuments(documents);
    assert.equal(buckets.documents.length, 1);
    assert.equal(buckets.corrigenda.length, 1);
    assert.equal(buckets.evaluationReports.length, 1);
    assert.equal(buckets.documents[0].url, 'https://epms.ppra.gov.pk/files/bidding-document.pdf');
});

/* -------------------------------------------------------------- filters */

test('restricted weapon and controlled-substance procurement is excluded', () => {
    assert.equal(isRestricted({ title: 'Supply of 7.62mm ammunition' }), true);
    assert.equal(isRestricted({ title: 'Procurement of assault rifles' }), true);
    assert.equal(isRestricted({ title: 'Purchase of detonators and blasting caps' }), true);
    assert.equal(isRestricted({ title: 'Supply of ephedrine' }), true);
    assert.equal(isRestricted({ title: 'Supply of agriculture tool kits' }), false);
    assert.equal(isRestricted({ title: 'Supply of safety shoes and helmets' }), false);
});

test('isActive uses both portal status and closing date', () => {
    const now = new Date('2026-09-07T09:00:00+05:00');
    assert.equal(isActive({ status: 'Published', closingDate: '2026-09-24' }, now), true);
    assert.equal(isActive({ status: 'Cancelled', closingDate: '2026-09-24' }, now), false);
    assert.equal(isActive({ status: 'Published', closingDate: '2026-09-01' }, now), false);
    assert.equal(isActive({ status: null, closingDate: null }, now), true, 'unknown stays visible');
});

test('evaluateTender applies keyword, agency and date filters', () => {
    const now = new Date('2026-09-07T09:00:00+05:00');
    const tender = {
        source: 'federal',
        title: 'Supply of Agriculture Tool Kits',
        description: 'Tool kits for five districts',
        procuringAgency: 'UNDP Pakistan',
        province: 'Federal',
        status: 'Published',
        publishedDate: '2026-09-01',
        closingDate: '2026-09-24',
    };

    assert.equal(evaluateTender(tender, { keyword: 'tool kit' }, now).keep, true);
    assert.equal(evaluateTender(tender, { keyword: 'ambulance' }, now).keep, false);
    assert.equal(evaluateTender(tender, { procuringAgencies: ['undp'] }, now).keep, true);
    assert.equal(evaluateTender(tender, { procuringAgencies: ['unicef'] }, now).keep, false);
    assert.equal(evaluateTender(tender, { deadlineTo: '2026-09-10' }, now).keep, false);
    assert.equal(evaluateTender(tender, { activeOnly: true }, now).keep, true);
    assert.equal(
        evaluateTender({ ...tender, closingDate: '2026-09-01' }, { activeOnly: true }, now).keep,
        false,
    );
});

test('sortTenders sorts stably and pushes nulls last in both directions', () => {
    const items = [
        { title: 'B', closingDate: '2026-09-20' },
        { title: 'A', closingDate: null },
        { title: 'C', closingDate: '2026-09-10' },
    ];
    assert.deepEqual(sortTenders(items, 'closingDate', true).map((i) => i.title), ['C', 'B', 'A']);
    assert.deepEqual(sortTenders(items, 'closingDate', false).map((i) => i.title), ['B', 'C', 'A']);
});

/* ---------------------------------------------------------- deduplicate */

test('deduplication uses the id key first and the composite fallback second', () => {
    const withId = { source: 'federal', tenderId: 'TS-2026-0091', title: 'Tool kits', procuringAgency: 'MNFSR', closingDate: '2026-09-24' };
    assert.equal(dedupeKey(withId), 'federal:ts 2026 0091');

    const withoutId = { source: 'punjab', tenderId: null, title: 'Supply of Furniture', procuringAgency: 'C&W Dept', closingDate: '2026-09-24' };
    assert.equal(dedupeKey(withoutId), 'punjab:supply of furniture:c w dept:2026-09-24');

    const deduper = new Deduplicator();
    assert.equal(deduper.add(withId), true);
    assert.equal(deduper.add({ ...withId }), false);
    assert.equal(deduper.add(withoutId), true);
    assert.equal(deduper.add({ ...withoutId }), false);
    assert.equal(deduper.duplicates, 2);

    // Same tender re-encountered without an id still collapses.
    assert.equal(deduper.add({ ...withId, tenderId: null, referenceNumber: null }), false);
});

/* --------------------------------------------------------------- registry */

test('every declared source resolves to an adapter with a valid contract', () => {
    const { adapters, unknown } = resolveAdapters(ALL_SOURCE_KEYS);
    assert.equal(unknown.length, 0);
    assert.equal(adapters.length, 7);

    for (const adapter of adapters) {
        assert.ok(adapter.key && adapter.name && adapter.province, `${adapter.key} metadata`);
        assert.ok(['cheerio', 'playwright'].includes(adapter.engine), `${adapter.key} engine`);
        assert.equal(typeof adapter.startRequests, 'function', `${adapter.key} startRequests`);
        assert.equal(typeof adapter.parseList, 'function', `${adapter.key} parseList`);
        assert.equal(typeof adapter.parseDetail, 'function', `${adapter.key} parseDetail`);

        const requests = adapter.startRequests({ activeOnly: true });
        assert.ok(requests.length > 0, `${adapter.key} produces entry points`);
        for (const request of requests) assert.doesNotThrow(() => new URL(request.url));
    }
});

test('unknown source keys are reported rather than silently dropped', () => {
    const { adapters, unknown } = resolveAdapters(['federal', 'atlantis']);
    assert.equal(adapters.length, 1);
    assert.deepEqual(unknown, ['atlantis']);
});
